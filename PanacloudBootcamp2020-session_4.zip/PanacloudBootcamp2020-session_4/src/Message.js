import React from 'react';

export function Message (props){
    return(
        <h3>Value of counter variable is: {props.counter}</h3>
    )
}