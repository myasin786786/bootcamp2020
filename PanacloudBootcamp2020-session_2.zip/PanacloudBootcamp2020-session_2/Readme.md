This is only for bootcamp classes
